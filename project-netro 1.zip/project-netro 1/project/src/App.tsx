import React from 'react';
import { Coffee, Clock, MapPin, Phone, Instagram, Facebook, Twitter } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-netro-black text-netro-white">
      {/* Navigation */}
      <nav className="fixed w-full bg-netro-black/90 backdrop-blur-sm z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-2xl font-display font-bold">NETRO</h1>
          <div className="hidden md:flex space-x-8">
            <a href="#home" className="hover:text-netro-copper transition-colors">Home</a>
            <a href="#menu" className="hover:text-netro-copper transition-colors">Menu</a>
            <a href="#about" className="hover:text-netro-copper transition-colors">About</a>
            <a href="#contact" className="hover:text-netro-copper transition-colors">Contact</a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative h-screen flex items-center justify-center">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=2000" 
            alt="Coffee" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-netro-black/60"></div>
        </div>
        <div className="relative container mx-auto px-4 text-center">
          <h2 className="text-6xl md:text-7xl font-display font-bold mb-6">
            Taste The Difference
          </h2>
          <p className="text-xl md:text-2xl max-w-2xl mx-auto mb-8">
            Welcome to Netro Coffee and Culinary Haven, where passion meets perfection in every cup.
          </p>
          <a 
            href="#menu"
            className="inline-block px-8 py-3 bg-netro-copper text-netro-white rounded hover:bg-netro-copper/90 transition-colors"
          >
            Explore Our Menu
          </a>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-netro-gray">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center text-netro-black">
              <Coffee className="w-12 h-12 text-netro-copper mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Premium Coffee</h3>
              <p>Hand-selected beans roasted to perfection</p>
            </div>
            <div className="text-center text-netro-black">
              <Clock className="w-12 h-12 text-netro-copper mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Open Daily</h3>
              <p>9:00 AM - 3:00 PM But on Friday from 1:00 pm to 3:00 pm </p>
            </div>
            <div className="text-center text-netro-black">
              <MapPin className="w-12 h-12 text-netro-copper mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Location</h3>
              <p>First branch: Mit Ghamr - Select Street</p>
             <p> Second branch: Mit Ghamr - First Port Said (Take Awa)</p>
            </div>
          </div>
        </div>
      </section>

      {/* Menu Section */}
      <section id="menu" className="py-20 bg-netro-black">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-display font-bold text-center mb-16">Our Menu</h2>
          
          {/* Hot Drinks */}
          <div className="mb-16">
            <h3 className="text-3xl font-display text-netro-copper mb-8">Hot Drinks</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {[
                { name: "Hot Chocolate", price: "65", desc: "Rich hot chocolate with whipped cream" },
                { name: "Hot Chocolate Marshmallow", price: "75", desc: "Hot chocolate topped with fluffy marshmallows" },
                { name: "Hot Lotus Cream", price: "105", desc: "Creamy lotus drink with whipped cream" },
                { name: "Hot Oreo", price: "70", desc: "Hot chocolate with crushed Oreos" },
                { name: "Turkish Coffee", price: "45", desc: "Authentic Turkish coffee, traditionally prepared" },
                { name: "Sahlab", price: "65", desc: "Traditional Middle Eastern hot drink" }
              ].map((item, index) => (
                <div key={index} className="flex justify-between items-center border-b border-netro-copper/20 pb-4">
                  <div>
                    <h4 className="text-xl font-semibold">{item.name}</h4>
                    <p className="text-sm text-gray-400">{item.desc}</p>
                  </div>
                  <div className="text-netro-copper font-semibold">{item.price}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Iced Tea & Refreshments */}
          <div className="mb-16">
            <h3 className="text-3xl font-display text-netro-copper mb-8">Iced Tea & Refreshments</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {[
                { name: "Iced Tea", price: "55", desc: "Classic refreshing iced tea" },
                { name: "Strawberry Iced Tea", price: "70", desc: "Iced tea with fresh strawberry" },
                { name: "Peach Iced Tea", price: "70", desc: "Iced tea with sweet peach" },
                { name: "Passion Fruit Iced Tea", price: "70", desc: "Exotic passion fruit iced tea" },
                { name: "Lemon Mint Iced Tea", price: "60", desc: "Refreshing blend with mint and lemon" }
              ].map((item, index) => (
                <div key={index} className="flex justify-between items-center border-b border-netro-copper/20 pb-4">
                  <div>
                    <h4 className="text-xl font-semibold">{item.name}</h4>
                    <p className="text-sm text-gray-400">{item.desc}</p>
                  </div>
                  <div className="text-netro-copper font-semibold">{item.price}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Milkshakes */}
          <div className="mb-16">
            <h3 className="text-3xl font-display text-netro-copper mb-8">Premium Milkshakes</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {[
                { name: "Nutella Milkshake", price: "95", desc: "Rich chocolate hazelnut shake" },
                { name: "Lotus Milkshake", price: "110", desc: "Creamy caramelized biscuit shake" },
                { name: "Pistachio Milkshake", price: "115", desc: "Premium pistachio blend" },
                { name: "Rocher Milkshake", price: "145", desc: "Luxury chocolate hazelnut creation" }
              ].map((item, index) => (
                <div key={index} className="flex justify-between items-center border-b border-netro-copper/20 pb-4">
                  <div>
                    <h4 className="text-xl font-semibold">{item.name}</h4>
                    <p className="text-sm text-gray-400">{item.desc}</p>
                  </div>
                  <div className="text-netro-copper font-semibold">{item.price}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Fresh Smoothies */}
          <div className="mb-16">
            <h3 className="text-3xl font-display text-netro-copper mb-8">Fresh Smoothies</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {[
                { name: "Strawberry", price: "75", desc: "Fresh strawberry smoothie" },
                { name: "Mango", price: "75", desc: "Tropical mango blend" },
                { name: "Mixed Berry", price: "75", desc: "Berry medley smoothie" },
                { name: "Passion Fruit", price: "75", desc: "Exotic passion fruit blend" }
              ].map((item, index) => (
                <div key={index} className="flex justify-between items-center border-b border-netro-copper/20 pb-4">
                  <div>
                    <h4 className="text-xl font-semibold">{item.name}</h4>
                    <p className="text-sm text-gray-400">{item.desc}</p>
                  </div>
                  <div className="text-netro-copper font-semibold">{item.price}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Specialty Coffee */}
          <div className="mb-16">
            <h3 className="text-3xl font-display text-netro-copper mb-8">Specialty Coffee</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-netro-gray/10 rounded-lg p-6">
                <img 
                  src="https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=800" 
                  alt="Turkish Coffee"
                  className="w-full h-48 object-cover rounded-lg mb-4"
                />
                <h4 className="text-xl font-semibold mb-2">Turkish Coffee</h4>
                <p className="text-sm text-gray-400 mb-4">Bold and freshly ground to perfection, brewed slowly for a deep, aromatic taste.</p>
              </div>
              <div className="bg-netro-gray/10 rounded-lg p-6">
                <img 
                  src="https://images.unsplash.com/photo-1511920170033-f8396924c348?auto=format&fit=crop&w=800" 
                  alt="Cappuccino"
                  className="w-full h-48 object-cover rounded-lg mb-4"
                />
                <h4 className="text-xl font-semibold mb-2">Cappuccino</h4>
                <p className="text-sm text-gray-400 mb-4">A perfect balance of rich espresso, steamed milk, and a velvety foam topping.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-netro-black">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-display font-bold mb-6">Our Story</h2>
              <p className="text-lg mb-6">
                Established in 2022, Netro Cafe & More has been serving premium coffee and culinary delights to our community. Our passion for quality and service excellence sets us apart.
              </p>
              <p className="text-lg">
                Every cup of coffee we serve is crafted with care, using only the finest beans sourced from sustainable farms around the world.
              </p>
            </div>
            <div>
              <img 
                src="https://images.unsplash.com/photo-1442512595331-e89e73853f31?auto=format&fit=crop&w=1000" 
                alt="Coffee brewing" 
                className="rounded-lg shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-netro-black py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-xl font-display font-bold mb-4">Contact Us</h3>
              <div className="space-y-2">
                <p className="flex items-center">
                  <Phone className="w-5 h-5 mr-2 text-netro-copper" />
                  0103289392222
                </p>
                <p className="flex items-center">
                  <MapPin className="w-5 h-5 mr-2 text-netro-copper" />
                  First branch: Mit Ghamr - Select Street
                  Second branch: Mit Ghamr - First Port Said (Take Awa)
                </p>
              </div>
            </div>
            <div>
              <h3 className="text-xl font-display font-bold mb-4">Hours</h3>
              <p>Open Daily</p>
              <p>9:00 AM - 3:00 PM But on Friday from 1:00 pm to 3:00 pm</p>
            </div>
            <div>
              <h3 className="text-xl font-display font-bold mb-4">Follow Us</h3>
              <div className="flex space-x-4">
                <a href="#" className="text-netro-copper hover:text-netro-copper/80 transition-colors">
                  <Instagram className="w-6 h-6" />
                </a>
                <a href="#" className="text-netro-copper hover:text-netro-copper/80 transition-colors">
                  <Facebook className="w-6 h-6" />
                </a>
                <a href="https://www.facebook.com/netro.egy/" className="text-netro-coppehover:text-netro-copper/80 transition-colors">
                  <Twitter className="w-6 h-6" />
                </a>
              </div>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t border-netro-copper/20 text-center">
            <p>&copy; 2022 Netro Cafe & More. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;